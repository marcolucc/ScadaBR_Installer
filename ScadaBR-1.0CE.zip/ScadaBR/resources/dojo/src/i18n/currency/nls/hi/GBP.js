/*
	Copyright (c) 2004-2006, The Dojo Foundation
	All Rights Reserved.

	Licensed under the Academic Free License version 2.1 or above OR the
	modified BSD license. For more information on Dojo licensing, see:

		http://dojotoolkit.org/community/licensing.shtml
*/



({"displayName":"\u092c\ufffd?\u0930\u093f\u0924\u0928 \u0915\u093e \u092a\u094c\u0928\ufffd?\u0921 \u0938\ufffd?\u091f\u0930\ufffd?\u0932\u093f\u0917", "symbol":"\xa3"})